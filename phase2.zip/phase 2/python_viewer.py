import cv2
import mediapipe as mp
import recognition
import json
import time

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_holistic = mp.solutions.holistic

face_mesh = mp.solutions.face_mesh.FaceMesh(refine_landmarks=True)
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.7)

cam = cv2.VideoCapture(0)
show_num = False
show_num2 = False
show_land_f = True
show_land_h = True
rec = recognition.Reco()

while True:
    _, frame = cam.read()
    frame = cv2.flip(frame, 1)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    mesh = face_mesh.process(rgb_frame)
    hand_res = hands.process(rgb_frame)
    frame_h, frame_w, _ = frame.shape
    
    data = {
        'hand': [],
        'face': [],
        'face_recognition': [],
        'emotion': {},
        'name': []
    }
    
    hand_landmarks = hand_res.multi_hand_landmarks
    if hand_landmarks:
        n = 0
        for landmarks in hand_landmarks:
            hand_points = []
            for landmark in landmarks.landmark:
                x = int(landmark.x * frame_w)
                y = int(landmark.y * frame_h)
                hand_points.append({'n': n, 'x': x, 'y': y})
                if show_land_h:
                    cv2.circle(frame, (x, y), 5, (0, 0, 255), -1)
                if show_num2:
                    cv2.putText(frame, f"{n}", (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 0, 0), 1)
                n += 1
            data['hand'].append(hand_points)

    landmarks_points = mesh.multi_face_landmarks
    if landmarks_points:
        message = rec.process(rgb_frame,0.4)
        data['name'] = message
        # print(time.time(),data['name'])
        if len(data['name']) !=0 and data['name']!=['unknown']:
            cv2.putText(frame,"UNLOCKED", (20,40),cv2.FONT_HERSHEY_COMPLEX,1.0,(255,0,0),thickness=2)
            #send data to arduino
        else:
            cv2.putText(frame,"LOCKED", (20,40),cv2.FONT_HERSHEY_COMPLEX,1.0,(255,0,0),thickness=2)
        for landmarks in landmarks_points:
            face_points = []
            n = 0
            for landmark in landmarks.landmark:
                x = int(landmark.x * frame_w)
                y = int(landmark.y * frame_h)
                face_points.append({'n': n, 'x': x, 'y': y})
                if show_land_f:
                    cv2.circle(frame, (x, y), 1, (0, 255, 0), -1)
                if show_num:
                    cv2.putText(frame, f"{n}", (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 0, 0), 1)
                n += 1
            data['face'].append(face_points)
        
    cv2.imshow('frame', frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('1'):
        show_land_f = not show_land_f
    elif key == ord('2'):
        show_num = not show_num
    elif key == ord('3'):
        show_land_h = not show_land_h
    elif key == ord('4'):
        show_num2 = not show_num2

cam.release()
cv2.destroyAllWindows()

