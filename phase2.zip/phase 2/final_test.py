# Import libraries
import cv2  
import mediapipe as mp  
import face_recognition  
import numpy as np  

# Initialize MediaPipe hands module
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils  # Drawing the hand landmarks

# Function to count the number of raised fingers
def count_fingers(hand_landmarks, hand_label):
    # Finger tips (index 4 is thumb, 8 is index finger, etc.)
    finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky
    finger_folded = [2, 6, 10, 14, 18]  # Knuckles before the tips (where fingers bend)
    
    fingers_up = []  # List to store the state (up or down) of each finger

    # Thumb (for left and right hands, compare x-coordinates differently)
    if hand_label == "Right":  # For right hand
        if hand_landmarks.landmark[finger_tips[0]].x < hand_landmarks.landmark[finger_folded[0]].x:
            fingers_up.append(1)  # Thumb is up
        else:
            fingers_up.append(0)  # Thumb is down
    else:  # For left hand
        if hand_landmarks.landmark[finger_tips[0]].x > hand_landmarks.landmark[finger_folded[0]].x:
            fingers_up.append(1)  # Thumb is up
        else:
            fingers_up.append(0)  # Thumb is down

    # For the other fingers, check if tip is higher (y-coordinate) than knuckle
    for i in range(1, 5):  # For the other four fingers
        if hand_landmarks.landmark[finger_tips[i]].y < hand_landmarks.landmark[finger_folded[i]].y:
            fingers_up.append(1)  # Finger is up
        else:
            fingers_up.append(0)  # Finger is down

    # Return the sum of raised fingers
    return sum(fingers_up)

# Load and encode multiple reference images of the user's face for recognition
reference_images = [
    "people\\mostafa.jpg",  # Image paths of reference faces
    "people\\mostafa3.jpg",
    "people\\mostafa7.jpg",
    "people\\mostafa8.jpg",
    "people\\mostafa10.jpg"
]
reference_encodings = []  # List to store encoded face data

# Load each reference image and encode the face for comparison later
for image_path in reference_images:
    image = face_recognition.load_image_file(image_path)  # Load the image
    encodings = face_recognition.face_encodings(image)  # Get face encodings
    if encodings:  # If face encoding is found
        reference_encodings.append(encodings[0])  # Append the encoding

# Initialize webcam for live video capture
cap = cv2.VideoCapture(0)

# Use MediaPipe Hands module for hand tracking (with detection and tracking confidence thresholds)
with mp_hands.Hands(static_image_mode=False, max_num_hands=1, min_detection_confidence=0.7, min_tracking_confidence=0.7) as hands:
    while cap.isOpened():  # Loop until the video feed is closed
        ret, frame = cap.read()  # Capture a frame from the webcam
        if not ret:  # If frame capture fails
            print("Failed to grab frame")
            break

        # Flip the frame horizontally (mirror effect) and convert to RGB for processing
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Process the frame with face_recognition to detect faces
        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

        # Variable to track if the "unlocked" person is detected
        unlocked_person_detected = False

        # Compare each detected face with the reference encodings
        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            matches = face_recognition.compare_faces(reference_encodings, face_encoding)  # Compare face encoding with reference faces
            name = "LOCKED"  # Default name if face doesn't match

            if True in matches:  # If there is a match
                name = "UNLOCKED"  # Set name to unlocked
                unlocked_person_detected = True  # Mark that the unlocked person is detected

            # Draw a rectangle around the face and label it with either "LOCKED" or "UNLOCKED"
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        # If the "unlocked" person is detected, track their hand
        if unlocked_person_detected:
            # Process the frame with MediaPipe Hands to detect hand landmarks
            hand_results = hands.process(rgb_frame)

            # Draw landmarks and count fingers for each detected hand
            if hand_results.multi_hand_landmarks:  # If hands are detected
                for idx, hand_landmarks in enumerate(hand_results.multi_hand_landmarks):  # For each hand
                    mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)  # Draw the hand landmarks

                    # Determine if the hand is left or right
                    hand_label = hand_results.multi_handedness[idx].classification[0].label  # "Left" or "Right"

                    # Count the number of fingers raised using the defined function
                    num_fingers = count_fingers(hand_landmarks, hand_label)

                    # Display action based on the hand and number of fingers
                    if hand_label == "Right" and num_fingers == 2:
                        cv2.putText(frame, "Turning Right", (350, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
                    elif hand_label == "Left" and num_fingers == 2:
                        cv2.putText(frame, "Turning Left", (350, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

                    # Display the hand label and number of fingers detected
                    cv2.putText(frame, f'{hand_label} Hand: {num_fingers} fingers', (10, 70 + idx * 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)

        # Display the current frame with the processed data
        cv2.imshow('CAMERA STREAMING', frame)

        # Exit the loop if the 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

# Release resources and close the window
cap.release()
cv2.destroyAllWindows()
