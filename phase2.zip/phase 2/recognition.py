import face_recognition
import cv2
import numpy as np
import os

class Reco:
    def __init__(self, dir="people"):
        self.known_face_encodings = []
        self.known_face_names = []
        for filename in os.listdir(dir): # listdir betgeb kol el filat aly gowa el folder
            file_path = os.path.join(dir, filename) # bet3del el path
            if os.path.isfile(file_path):
                self.known_face_names.append(os.path.splitext(filename)[0])  # Using os.path.splitext to get the filename without extension
                self.known_face_encodings.append(face_recognition.face_encodings(face_recognition.load_image_file(file_path))[0])
    
    def process(self, rgb_small,tolerance):  # rgb, the lower the tolerance the better
        face_locations = []
        face_encodings = []
        # rgb_small = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        #rgb_small = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
        face_locations = face_recognition.face_locations(rgb_small)
        face_encodings = face_recognition.face_encodings(rgb_small, face_locations)
        face_names = []

        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(self.known_face_encodings, face_encoding, tolerance)
            name = "unknown"

            face_distance = face_recognition.face_distance(self.known_face_encodings, face_encoding)
            best_match = np.argmin(face_distance)

            if matches[best_match]:
                name = self.known_face_names[best_match]

            face_names.append(name)
        
        return face_names