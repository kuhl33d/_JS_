# Import libraries
import cv2
import mediapipe as mp
import face_recognition
import numpy as np

# Initialize MediaPipe hands module
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils  # Draws hand landmarks

# Function to count fingers
def count_fingers(hand_landmarks, hand_label):
    finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky
    finger_folded = [2, 6, 10, 14, 18]  # Knuckles before tips
    
    fingers_up = []
    # Thumb
    if hand_label == "Right":
        fingers_up.append(1 if hand_landmarks.landmark[finger_tips[0]].x < hand_landmarks.landmark[finger_folded[0]].x else 0)
    else:
        fingers_up.append(1 if hand_landmarks.landmark[finger_tips[0]].x > hand_landmarks.landmark[finger_folded[0]].x else 0)

    # Other fingers
    for i in range(1, 5):
        fingers_up.append(1 if hand_landmarks.landmark[finger_tips[i]].y < hand_landmarks.landmark[finger_folded[i]].y else 0)

    return sum(fingers_up)

# Load reference images and encode faces
reference_images = [
    "people\\mostafa.jpg",
    "people\\mostafa3.jpg",
    "people\\mostafa7.jpg",
    "people\\mostafa8.jpg",
    "people\\mostafa10.jpg"
]
reference_encodings = []
for image_path in reference_images:
    image = face_recognition.load_image_file(image_path)
    encodings = face_recognition.face_encodings(image)
    if encodings:
        reference_encodings.append(encodings[0])

# Initialize webcam
cap = cv2.VideoCapture(0)

# Initialize MediaPipe Hands
with mp_hands.Hands(static_image_mode=False, max_num_hands=1, min_detection_confidence=0.7, min_tracking_confidence=0.7) as hands:
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame.")
            break

        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Detect hands
        hand_results = hands.process(rgb_frame)

        # Detect faces
        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

        # Process only the first detected face
        if face_encodings:
            face_encoding = face_encodings[0]
            matches = face_recognition.compare_faces(reference_encodings, face_encoding, tolerance=0.4)
            name = "LOCKED"
            if True in matches:
                name = "UNLOCKED"

            # Draw rectangle and label
            (top, right, bottom, left) = face_locations[0]
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        # Draw hand landmarks and count fingers
        if name == "UNLOCKED" and hand_results.multi_hand_landmarks:
            for idx, hand_landmarks in enumerate(hand_results.multi_hand_landmarks):
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                hand_label = hand_results.multi_handedness[idx].classification[0].label
                num_fingers = count_fingers(hand_landmarks, hand_label)

                if hand_label == "Right" and num_fingers == 2:
                    cv2.putText(frame, "Turning Right", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                elif hand_label == "Left" and num_fingers == 2:
                    cv2.putText(frame, "Turning Left", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

                cv2.putText(frame, f'{hand_label} Hand: {num_fingers} fingers', (10, 70 + idx * 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        cv2.imshow('MediaPipe Hand and Face Recognition', frame)

        # Exit on 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()
